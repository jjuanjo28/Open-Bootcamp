import React from 'react';

const TaskPage = () => {
    return (
        <div>
            <h1>Soy Task Page</h1>
        </div>
    );
}

export default TaskPage;
