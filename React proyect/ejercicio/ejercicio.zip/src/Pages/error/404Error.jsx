import React from 'react';

const ErrorPage = () => {
    return (
        <div>
            <h1>404 error page</h1>
        </div>
    );
}

export default ErrorPage;
