import React from 'react';

const LoginPage = () => {
    return (
        <div>
            <h1>Soy Login</h1>
        </div>
    );
}

export default LoginPage;
