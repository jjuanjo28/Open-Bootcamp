import React,{ useState } from 'react';
import { useNavigate } from "react-router-dom"

const HomePage = ({padreAHijo, hijoAPadre}) => {
 
    const navigate = useNavigate()
        const goTo = () => {
        navigate("/task")
    }
    const datosPadre = !padreAHijo
    
    return (
        <div>
            <h1>Soy Home</h1>
            <h2>el estado es: {padreAHijo ? "On-Line" : "Off-Line"} </h2>
            <button onClick={goTo}>TO TASK</button>
           <button onClick={()=> hijoAPadre(datosPadre)}>change state</button>
           
        </div>
    );
}

export default HomePage;
