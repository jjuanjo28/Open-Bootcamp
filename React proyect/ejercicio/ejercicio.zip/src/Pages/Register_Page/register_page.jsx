import React from 'react';

const RegisterPage = () => {
    return (
        <div>
            <h1>Register Page</h1>
        </div>
    );
}

export default RegisterPage;
