import React,{ useState } from 'react'
import './App.css'
import {BrowserRouter as Router, Routes, Route, Link, Navigate} from "react-router-dom"
import HomePage from './Pages/Home/Home_page'
import ErrorPage from './Pages/error/404Error'
import LoginPage from './Pages/Login_Page/login_page'
import RegisterPage from './Pages/Register_Page/register_page'
import TaskPage from './Pages/Task_Page/Task_page'

function App() {

  const [logged, setlogged] = useState(true)

  function padreAHijo() {
    setlogged(!logged)
  }
  function changeState(datos) {
    setlogged(datos)
  }
 
  return (
    <div className="App">
         
         <Router>
         <Link to={"/"} element={<HomePage/>}>|| HOME |</Link>
         <Link to={"/login"} element={<LoginPage/>}>| LOGIN |</Link>
         <Link to={"/register"} element={<RegisterPage/>}>| REGISTER ||</Link>
          <button onClick={()=> padreAHijo()}>Change State</button>
          <Routes>
            <Route exact path='/' element={<HomePage padreAHijo={logged} hijoAPadre={changeState}/>}/>
            <Route path="/login" element={<LoginPage/>}/>
            <Route path="/register" element={<RegisterPage/>}/>
            <Route path="/task" element={
                    logged ? <TaskPage/> : <Navigate replace to="/login"/>}/>
            <Route path="*" element={<ErrorPage/>}/>
          </Routes>
         </Router>
    </div>
  )
}

export default App
