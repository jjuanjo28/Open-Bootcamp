let nombre = "Juan";
let apellido = "Tonut";
let estudiante = nombre + " " + apellido;
let estudianteMayus = estudiante.toUpperCase();
let estudianteMinus = estudiante.toLocaleLowerCase();
let numLetras = estudiante.length;
let primeraLetraEst = estudiante[0];
let ultimaLetraEst = estudiante[estudiante.length-1];
let estudianteSinEspacios = estudiante.replace(" ","");
let buleano = estudiante.includes(nombre)

