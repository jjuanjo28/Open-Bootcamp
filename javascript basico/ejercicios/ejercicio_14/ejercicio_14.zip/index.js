
let boton = document.getElementById("btn")

boton.addEventListener("click",
 () => {alert("click en el boton")}
)
$("#btn").click(() => {
    console.log("Hola, estoy utilizando jQuery")})