let nombre = "Juanjo";
let edad = 47;
let desarrollador = true;
let nacimiento = new Date(1975,09,30);
let libro = {
    titulo : "Harry Potter y la piedra filosofal",
    autor : " J. K. Rowling",
    año: 1997,
    url: false
}
