let parrafo = document.querySelectorAll(".parrafo");
let contenedor = document.querySelectorAll(".contenedor");
let trashBox = document.querySelector(".trash-box");
let restoreButton = document.querySelector(".restore")
let trashArray = []
parrafo.forEach(parrafo =>{

    parrafo.addEventListener("dragstart",(event)=>{
      parrafo.classList.add("dragged")
      event.dataTransfer.setData("id",parrafo.id)
     })

    parrafo.addEventListener("dragend",()=>{
      parrafo.classList.remove("dragged")
    })
})

contenedor.forEach(contenedor=>{
    contenedor.addEventListener("dragover",(event)=>{
        event.preventDefault()
    })
    contenedor.addEventListener("drop",(event)=>{
     let id_contenedor = event.dataTransfer.getData("id")
     let container = document.getElementById(id_contenedor)
        contenedor.appendChild(container)
    })
})

restoreButton.addEventListener("click",()=>{
    if(trashArray.length == 0) return alert("no hay elementos borrados a recuperar")
    let dato = trashArray.shift()
   contenedor[0].appendChild(dato)
    console.log(dato)
    console.log(trashArray)
})

trashBox.addEventListener("dragover",(event)=>{
    event.preventDefault()
})
trashBox.addEventListener("drop",(event)=>{
    let id_contenedor = event.dataTransfer.getData("id")
    let container = document.getElementById(id_contenedor)
    let nuevocont = container
    trashArray.push(nuevocont)
    container.remove()
    console.log(trashArray)
})