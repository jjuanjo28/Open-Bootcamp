const familia = new Set(["Juanjo","Carlos","Ignacio"]);
console.log(familia);
familia.add("Juanjo");
familia.add("Javascript");
console.log(familia)