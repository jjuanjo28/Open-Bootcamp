let fecha = new Date(2022,11,5);
let fechaNacimiento = new Date(1975,09,30);
let esMasTarde = (fecha>fechaNacimiento);
let diaDeNacimiento = fechaNacimiento.getDate();
let mesDeNacimiento = fechaNacimiento.getMonth()+1;
let añoDeNacimiento = fechaNacimiento.getFullYear();
