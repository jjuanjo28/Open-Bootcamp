let altura = 1790;
let alturaEnMetros = 1.790;
let pesoEnKg = 54.5;
let alturaRedondeadaArriba = Math.round(alturaEnMetros);
let alturaRedondeadaAbajo = Math.floor(alturaEnMetros);
let maxNumJavascript = Number.MAX_VALUE + 1

