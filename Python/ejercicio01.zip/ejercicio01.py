a="hola mundo"
print(a)